Deployement steps:
Make sure python version 3 is installed.
Make sure pip3 is installed

After you enter the parent folder.

Install all the required python modules by using the following command
pip3 install requirements.txt
